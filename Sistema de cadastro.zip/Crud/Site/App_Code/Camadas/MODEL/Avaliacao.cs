﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Camadas.MODEL
{
    public class Avaliacao
    {
        public int nota { get; set; }
        public DateTime ano { get; set; }
    }
}