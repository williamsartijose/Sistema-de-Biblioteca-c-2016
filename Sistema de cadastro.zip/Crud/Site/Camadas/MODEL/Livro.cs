﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Camadas.MODEL
{
    public class Livro
    {
        public int id { get; set; }
        public string titulo { get; set; }
        public int edicao { get; set; }
        public int quantidade { get; set; }
        public string genero { get; set; }
        public string autor { get; set; }
       


        
    }
}
